__version__ = "__version__ = '2.7.0'"

from pythermalcomfort.models import *
